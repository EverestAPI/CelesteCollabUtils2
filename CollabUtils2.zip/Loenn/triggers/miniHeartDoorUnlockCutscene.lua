local trigger = {}
trigger.name = "CollabUtils2/MiniHeartDoorUnlockCutsceneTrigger"
trigger.placements = {
    {
        name = "default",
        data = {
            doorID = ""
        }
    }
}

return trigger
