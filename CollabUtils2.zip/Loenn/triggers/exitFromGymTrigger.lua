local trigger = {}
trigger.name = "CollabUtils2/ExitFromGymTrigger"
trigger.nodeLimits = {0, 1}
trigger.placements = {
    {
        name = "default"
    }
}

return trigger
