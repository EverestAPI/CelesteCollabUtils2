local trigger = {}
trigger.name = "CollabUtils2/RainbowBerryUnlockCutsceneTrigger"
trigger.placements = {
    {
        name = "default",
        data = {
            levelSet = "",
            maps = ""
        }
    }
}

return trigger
