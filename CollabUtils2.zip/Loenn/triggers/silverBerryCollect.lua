local trigger = {}
trigger.name = "CollabUtils2/SilverBerryCollectTrigger"
trigger.placements = {
    {
        name = "default"
    }
}

return trigger
