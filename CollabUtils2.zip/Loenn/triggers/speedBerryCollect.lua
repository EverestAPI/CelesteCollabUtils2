local trigger = {}
trigger.name = "CollabUtils2/SpeedBerryCollectTrigger"
trigger.placements = {
    {
        name = "default"
    }
}

return trigger
