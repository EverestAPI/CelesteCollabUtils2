local silverBerry = {}
silverBerry.name = "CollabUtils2/SilverBerry"
silverBerry.depth = -100
silverBerry.placements = {
    {
        name = "default",
        data = {
            alwaysSpawn = false
        }
    }
}

silverBerry.texture = "CollabUtils2/silverBerry/idle00"

return silverBerry
